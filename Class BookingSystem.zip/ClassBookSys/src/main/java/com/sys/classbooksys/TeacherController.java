package com.sys.classbooksys;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class TeacherController {

        @FXML
        private Button btnBack;

        @FXML
        private Button btn_save;

        @FXML
        private Button btn_view;

        @FXML
        private TableColumn<?, ?> idColumn;

        @FXML
        private Label lb_view;

        @FXML
        private TextField tf_classRoom;

        @FXML
        private TextField tf_description;

        @FXML
        private TextField tf_time_date;

        @FXML
        private TableColumn<?, ?> tv_description;

        @FXML
        void onBack(ActionEvent event) throws IOException {
                Parent root = FXMLLoader.load(getClass().getResource("MainDash.fxml"));
                Stage window = (Stage) btnBack.getScene().getWindow();
                window.setScene(new Scene(root));
                window.show();
        }

        @FXML
        void onSave(ActionEvent event) {
                if (tf_time_date.getText().isBlank() == false && tf_classRoom.getText().isBlank() == false && tf_description.getText().isBlank() == false) {
                        bookClass();
                } else {
                        lb_view.setText("Please enter valid details");
                }
        }

        @FXML
        void onView(ActionEvent event) {

        }

        public void bookClass() {
                DBConnect connect = new DBConnect();
                Connection conn = connect.getConnection();

                String time_date = tf_time_date.getText();
                String class_room = tf_classRoom.getText();
                String description = tf_description.getText();

                String insertFields = "INSERT INTO booking_details (time_date,class_room, description) VALUES ('";
                String insertVales = time_date + "','" + class_room + "','" + description + "')";
                String insertToDatabase = insertFields + insertVales;

                try {
                        Statement statement = conn.createStatement();
                        statement.executeUpdate(insertToDatabase);
                        lb_view.setText("Successfully added");

                        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
                        Stage window = (Stage) btn_save.getScene().getWindow();
                        window.setScene(new Scene(root));
                        window.show();

                } catch (SQLException e) {
                        e.printStackTrace();
                } catch (IOException e) {
                        e.printStackTrace();
                }

        }
}