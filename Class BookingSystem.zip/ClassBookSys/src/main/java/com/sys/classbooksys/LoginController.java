package com.sys.classbooksys;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginController {

    @FXML
    private Button btnExit;

    @FXML
    private Button btn_Login;

    @FXML
    private Button btn_SignUp;

    @FXML
    private AnchorPane pane;

    @FXML
    private TextField tf_Email;

    @FXML
    private PasswordField tf_password;

    @FXML
    private PasswordField tf_userType;

    @FXML
    private Label lb_view;

    @FXML
    void onExit(ActionEvent event) {
        Stage stage = (Stage) btnExit.getScene().getWindow();
        stage.close();
    }

    @FXML
    void onLogin(ActionEvent event) {

         if (tf_Email.getText().isBlank() == false && tf_password.getText().isBlank() == false && tf_userType.getText().isBlank() == false) {
            register();
        } else {
            lb_view.setText("Please enter valid details");
        }
    }


    public void register() {
        DBConnect connect = new DBConnect();
        Connection conn = connect.getConnection();

        String query = "SELECT *  FROM user_details WHERE (email = ? AND password = ?) AND userType = ?";

        try {
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, tf_Email.getText());
            pst.setString(2, tf_password.getText());
            pst.setString(3,tf_userType.getText());
            ResultSet queryResult = pst.executeQuery();
            if (queryResult.next()) {
                Parent root = FXMLLoader.load(getClass().getResource("MainDash.fxml"));
                Stage window = (Stage) btn_Login.getScene().getWindow();
                window.setScene(new Scene(root));
                window.show();
            }else {
            lb_view.setText("Please enter valid details");
        }

        } catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
    }


    @FXML
    void onSignup(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
        Stage window = (Stage) btn_SignUp.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }
}
