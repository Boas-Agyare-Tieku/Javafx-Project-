package com.sys.classbooksys;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class SignUpController {

    @FXML
    private Button btnExit;

    @FXML
    private Button btn_backlog;

    @FXML
    private Button btn_submit;

    @FXML
    private Label lb_view;

    @FXML
    private TextField tf_Contact;

    @FXML
    private TextField tf_Email;

    @FXML
    private TextField tf_FName;

    @FXML
    private TextField tf_SName;

    @FXML
    private PasswordField tf_password;

    @FXML
    private TextField tf_userType;

    @FXML
    void onBackToLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Stage window = (Stage) btn_backlog.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }

    @FXML
    void onExit(ActionEvent event) {
        Stage stage = (Stage) btnExit.getScene().getWindow();
        stage.close();
    }

    public void UserDetails() {
        DBConnect connect = new DBConnect();
        Connection conn = connect.getConnection();

        String fname = tf_FName.getText();
        String sname = tf_SName.getText();
        String email = tf_Email.getText();
        String contact = tf_Contact.getText();
        String password = tf_password.getText();
        String userType = tf_userType.getText();

        String insertFields = "INSERT INTO user_details (fname, sname, email, contact, password, userType)" +
                " VALUES (' ";
        String insertVales = fname + "', '" + sname + "', '" + email + "', '" + contact + "', '" + password + "', '" + userType + "')";
        String insertToDatabase = insertFields + insertVales;

        try {
            Statement statement = conn.createStatement();
            statement.executeUpdate(insertToDatabase);
            lb_view.setText("Successfully added");

            Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Stage window = (Stage) btn_submit.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();


        } catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }

    }

    @FXML
    void onSubmit(ActionEvent event) {
        if (tf_FName.getText().isBlank()== false&& tf_SName.getText().isBlank() == false && tf_Email.getText().isBlank()== false &&
                tf_Contact.getText().isBlank() == false && tf_password.getText().isBlank() == false && tf_userType.getText().isBlank() == false) {
            UserDetails();
        } else {
            lb_view.setText("Please enter valid details");
        }


    }


}
