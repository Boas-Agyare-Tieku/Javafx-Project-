package com.sys.classbooksys;

import java.sql.*;

public class DBConnect {

    public Connection databaseConnection;
    public Connection getConnection(){
        String dbName = "java_project";
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/" + dbName;
        String user = "root";
        String password = "";


        try {
            Class.forName(driver);
            databaseConnection = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }

        return databaseConnection;
    }







//        final  String Driver = "com.mysql.cj.jdbc.Driver";
//        final String DB_Name = "java_project";
//        final String DB_User = "root";
//        final String DB_Password = "";
//        final String DB_Url = "jdbc:mysql://" + DB_User + ":" + DB_Password + "@localhost/" + DB_Name;
//
//        public DBConnect() throws Exception {
//            Class.forName(Driver);
//            connection = DriverManager.getConnection(DB_Url);
//        }
//
//        Connection connection;
//        PreparedStatement prepareStatement;
//        ResultSet resultSet;
//
//        public int input (String fname, String sname, String email, String contact, String password,
//                          String userType) throws SQLException {String query= "INSERT INTO `user_details`(`id`, `fname`," +
//                " `sname`, `email`, `contact`, `password`, `userType`) VALUES(?, ?, ?, ?, ?, ?)";
//
//            PreparedStatement prepareStatement = connection.prepareStatement(query);
//            prepareStatement.setString(1, fname);
//            prepareStatement.setString(2, sname);
//            prepareStatement.setString(3, email);
//            prepareStatement.setString(4, contact);
//            prepareStatement.setString(5, password);
//            prepareStatement.setString(6, userType);
//
//            return prepareStatement.executeUpdate();
//
//        }
//
//        public int login(String email, String password, String userType) throws SQLException {
//            prepareStatement = connection.prepareStatement("SELECT count(1) FROM user_details WHERE email = ? and password = ? and userType = ?");
//
//            prepareStatement.setString(1, email);
//            prepareStatement.setString(2, password);
//            prepareStatement.setString(3, userType);
//
//                return 0;
//        }
}