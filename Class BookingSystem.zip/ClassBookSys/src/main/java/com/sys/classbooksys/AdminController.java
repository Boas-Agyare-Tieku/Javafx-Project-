package com.sys.classbooksys;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminController {

    @FXML
    private Label Welcome;

    @FXML
    private Label bookedClasses;

    @FXML
    private Button btn_approve;

    @FXML
    private Button btn_back;

    @FXML
    private Button btn_decline;

    @FXML
    private Button btn_save;

    @FXML
    private Button btn_select;

    @FXML
    private Button btn_view;

    @FXML
    private TableColumn<?, ?> classroomColumn;

    @FXML
    private TableColumn<?, ?> idColumn;

    @FXML
    private TableColumn<?, ?> timeColumn;

    @FXML
    private TableColumn<?, ?> tv_description;

    @FXML
    private TableView<?> viewTable;

    @FXML
    void onApprove(ActionEvent event) {

    }

    @FXML
    void onBack(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
        Stage window = (Stage) btn_back.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }

    @FXML
    void onDecline(ActionEvent event) {

    }

    @FXML
    void onSave(ActionEvent event) {

    }

    @FXML
    void onSelect(ActionEvent event) {

    }

    @FXML
    void onView(ActionEvent event) {

    }

}
