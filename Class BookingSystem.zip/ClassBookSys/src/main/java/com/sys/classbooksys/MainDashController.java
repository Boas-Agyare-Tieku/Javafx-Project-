package com.sys.classbooksys;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

import static javafx.fxml.FXMLLoader.load;

public class MainDashController {

    @FXML
    private Button btnAdmin;

    @FXML
    private Button btnLogout;

    @FXML
    private Button btnStudent;

    @FXML
    private Button btnTeacher;

    @FXML
    void toAdminPage(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
        Stage window = (Stage) btnAdmin.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();

    }

    @FXML
    void toLogout(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Stage window = (Stage) btnLogout.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }

    @FXML
    void toStudentPage(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Students.fxml"));
        Stage window = (Stage) btnStudent.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();

    }

    @FXML
    void toTeacherPage(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Teacher.fxml"));
        Stage window = (Stage) btnTeacher.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }
}
