package com.sys.classbooksys;

public class AdminModel {
    Integer id;
    String time_date;
    String description;
    String classroom;

    public AdminModel(Integer id, String time_date, String description, String classroom) {
        this.id = id;
        this.time_date = time_date;
        this.description = description;
        this.classroom = classroom;
    }
    public AdminModel(){

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTime_date() {
        return time_date;
    }

    public void setTime_date(String time_date) {
        this.time_date = time_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getClassroom() {
        return classroom;
    }

    public void setClassroom(String classroom) {
        this.classroom = classroom;
    }
}
