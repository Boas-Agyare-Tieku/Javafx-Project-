package com.sys.classbooksys;public class Mainstart {
    public static void main(String[] args) {
        startApp.main(args);
    }
}
