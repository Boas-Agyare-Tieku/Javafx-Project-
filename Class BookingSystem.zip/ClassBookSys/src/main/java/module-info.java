module com.sys.classbooksys {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.sys.classbooksys to javafx.fxml;
    exports com.sys.classbooksys;
}